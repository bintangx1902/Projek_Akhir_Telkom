/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author binta
 */

//import java.sql.*;
//import javax.swing.*;
//import java.util.*;
//import java.util.logging.*;

public class NewClass {
    public static void main(String[] args) {
//        String cetak = "";
//        String str = new String("MahaDewa");
//        System.out.println(str.substring(2));
//        System.out.println(str.substring(3,7));
//    Connection con = null;
//    Statement st = null;
//    ResultSet rs = null;
//    String sql, que = null;
//    
//    try {
//            Class.forName("com.mysql.jdbc.Driver");
//            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/pbo_1", "root", "");
//            st = con.createStatement();
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(null, "Koneksi Database gagal, Kesalahan pada : \n" + e);
//        }

    }
}
